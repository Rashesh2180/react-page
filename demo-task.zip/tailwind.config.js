/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  darkMode:"class",
  theme: {
    extend: {
      colors:{
        "primary":'#A23337',
        "secondary":"#222021",
        "green-200":"#858D38"
    
      }
    },
  },
  plugins: [],
}