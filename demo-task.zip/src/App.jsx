import React from "react";
import Header from "./components/header/Header";
import HomeHero from "./components/homeHero/HomeHero";
import FeatureList from "./components/featureList/FeatureList";

const App = () => {
  return (
    <>
      <Header />
      <HomeHero />
      <FeatureList />
    </>
  );
};

export default App;
